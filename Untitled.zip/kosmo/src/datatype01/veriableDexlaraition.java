package datatype01;

public class veriableDexlaraition {
	public static void main(String[] args) {
		System.out.println("[변수 선언 방법 첫 번째]");
		//자료형(data type) 변수명
		int num;// int형 (숫자-정수) 저장할 수 잇는 num 이라는 메모리에 할당해주세요
		num = 10; //변수 초기화
		
		int bnum = 0b1010;
		System.out.println(num);
		System.out.println(bnum);
		int onum = 012;
		int hnum = 0xA;
		System.out.println(onum);
		System.out.println(hnum);
		int intnum = 200;
		
		System.out.println(intnum);
		int frum,snum =300,trum;
		//항상 = 대입(할당)연산자의 왼쪽에는 
		// 값을 변경할 수 있는 변구가 와야한다.
		// 오른쪽에는 값이나 값이 저장된 변수가온다.
		//자바는 대소문자를 엄격하게 구분한다.
		
		int studentName; //겹치는 단어 첫번째는 대문자로 
		
		
		System.out.println(" i got my peaches out in Georgia "
				+ "oh yeah shit");
		
	}
}