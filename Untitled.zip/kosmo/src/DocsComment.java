/**\
	@author youngseo
	@version 1.0
	<h2> this class is not for Run - Time but for making Document</h2>\
*/


public class DocsComment {

	/**\
	@param num1 num1 is first number\
	@param num2 num2 is second number\
	@return return plusing num1 and num2 \
	*/

	public in getTotal(int num1, int num2)
		return num1 + num2;
	}

}