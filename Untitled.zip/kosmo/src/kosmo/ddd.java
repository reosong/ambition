package kosmo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ddd {
	public static void main(String[] args) {
		System.out.println("Hello wolrd!");
		Date date = new Date();
						
	}
}
