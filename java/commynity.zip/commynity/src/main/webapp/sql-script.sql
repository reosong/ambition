create database community;

use community;
create table member(

)